import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'; // Pastikan file App.tsx ada di folder src

const root = document.getElementById('root') as HTMLElement;
const rootElement = ReactDOM.createRoot(root);

rootElement.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
