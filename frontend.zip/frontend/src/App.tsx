import React from 'react';

const App = () => {
  return (
    <div>
      <h1>Welcome to Neutron (NTR)</h1>
    </div>
  );
};

export default App;
